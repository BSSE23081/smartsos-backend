import React, { useState, useEffect, createContext, useContext, useRef } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('currentUser')));
  const [allUsers, setAllUsers] = useState(JSON.parse(localStorage.getItem('users')) || [
    { email: 'admin@test.com', password: 'admin', name: 'Commander', role: 'admin' }
  ]);
  const [incidents, setIncidents] = useState(JSON.parse(localStorage.getItem('incidents')) || []);

  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(allUsers));
    localStorage.setItem('incidents', JSON.stringify(incidents));
  }, [allUsers, incidents]);

  const signup = (name, email, password, role) => {
    const newUser = { name, email, password, role };
    setAllUsers([...allUsers, newUser]);
    setUser(newUser);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
  };

  const login = (email, password) => {
    const found = allUsers.find(u => u.email === email && u.password === password);
    if (found) {
      setUser(found);
      localStorage.setItem('currentUser', JSON.stringify(found));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
    window.location.reload();
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, incidents, setIncidents }}>
      {children}
    </AuthContext.Provider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}

function MainLayout() {
  const { user } = useContext(AuthContext);
  const [mode, setMode] = useState('login');
  const [roleTarget, setRoleTarget] = useState(null);

  if (!user) {
    if (!roleTarget) return <RoleSelector setRoleTarget={setRoleTarget} />;
    return <AuthScreen role={roleTarget} mode={mode} setMode={setMode} goBack={() => setRoleTarget(null)} />;
  }

  return (
    <div style={styles.appContainer}>
      <div style={styles.mainArea}>
        {user.role === 'admin' ? <AdminDashboard /> : <UserSOSView />}
      </div>
      <footer style={styles.tickerBar}>
        <div className="ticker-text">
          <span> ⚠️ AI MODULE: ONLINE • NEURAL NETWORK CONNECTED • ANALYZING LIVE DATA • EMERGENCY PROTOCOL ACTIVE • </span>
          <span> ⚠️ AI MODULE: ONLINE • NEURAL NETWORK CONNECTED • ANALYZING LIVE DATA • EMERGENCY PROTOCOL ACTIVE • </span>
        </div>
      </footer>
    </div>
  );
}

// --- AUTH COMPONENTS ---
function RoleSelector({ setRoleTarget }) {
  return (
    <div style={styles.loginPage}>
      <h1 style={styles.heroTitle}>SMART<span>SOS</span></h1>
      <p style={{ color: '#94a3b8', marginBottom: '40px', letterSpacing: '2px' }}>SELECT SYSTEM INTERFACE</p>
      <div style={{ display: 'flex', gap: '30px' }}>
        <button onClick={() => setRoleTarget('user')} style={styles.roleCard}>
          <div style={{ fontSize: '40px' }}>📱</div>
          <div>CIVILIAN PORTAL</div>
        </button>
        <button onClick={() => setRoleTarget('admin')} style={{ ...styles.roleCard, borderColor: '#ef4444' }}>
          <div style={{ fontSize: '40px' }}>🛡️</div>
          <div>COMMAND CENTER</div>
        </button>
      </div>
    </div>
  );
}

function AuthScreen({ role, mode, setMode, goBack }) {
  const auth = useContext(AuthContext);
  const [form, setForm] = useState({ name: '', email: '', pass: '' });

  const handleSubmit = () => {
    if (mode === 'signup') auth.signup(form.name, form.email, form.pass, role);
    else auth.login(form.email, form.pass);
  };

  return (
    <div style={styles.loginPage}>
      <div style={styles.glassCard}>
        <h2 style={{ color: '#ef4444' }}>{role.toUpperCase()} ACCESS</h2>
        {mode === 'signup' && <input placeholder="Full Name" style={styles.darkInput} onChange={e => setForm({ ...form, name: e.target.value })} />}
        <input placeholder="Email" style={styles.darkInput} onChange={e => setForm({ ...form, email: e.target.value })} />
        <input type="password" placeholder="Passphrase" style={styles.darkInput} onChange={e => setForm({ ...form, pass: e.target.value })} />
        <button onClick={handleSubmit} style={styles.primaryBtn}>{mode === 'signup' ? 'REGISTER' : 'LOGIN'}</button>
        <p onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')} style={styles.toggleLink}>
          {mode === 'signup' ? 'Switch to Login' : 'Switch to Sign Up'}
        </p>
        <button onClick={goBack} style={styles.backBtn}>Back</button>
      </div>
    </div>
  );
}

// --- AI ASSISTANT COMPONENT ---
function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [chat, setChat] = useState([{ role: 'ai', text: 'I am SOS-AI. How can I help you survive today?' }]);
  const [input, setInput] = useState('');

  const getAIResponse = (query) => {
    const q = query.toLowerCase();
    const header = "<strong>[SYSTEM ANALYSIS: CRITICAL]</strong><br/>PROTOCOL: EMERGENCY RESPONSE v4.0<br/>-----------------------------<br/>";

    if (q.includes('fire')) {
      return header +
        "1. EVACUATE STRUCTURE IMMEDIATELY<br/>" +
        "2. STAY LOW (BELOW SMOKE CEILING)<br/>" +
        "3. UTILIZE DAMP CLOTH FOR FILTRATION<br/>" +
        "4. DO NOT USE ELEVATORS / LIFTS<br/>" +
        "5. CONFIRM ALL OCCUPANTS ARE OUT";
    }

    if (q.includes('bleed') || q.includes('blood')) {
      return header +
        "1. APPLY DIRECT SUSTAINED PRESSURE<br/>" +
        "2. ELEVATE WOUND ABOVE HEART LEVEL<br/>" +
        "3. DO NOT REMOVE SATURATED BANDAGES<br/>" +
        "4. MONITOR FOR SYMPTOMS OF SHOCK";
    }

    if (q.includes('cpr') || q.includes('heart')) {
      return header +
        "1. PLACE SUBJECT ON HARD SURFACE<br/>" +
        "2. COMPRESSIONS: 100-120 PER MINUTE<br/>" +
        "3. DEPTH: 2-2.4 INCHES (ADULT)<br/>" +
        "4. CONTINUE UNTIL MEDICAL ARRIVAL";
    }

    return "<strong>[WAITING FOR INPUT]</strong><br/>Describe the situation (e.g., 'Fire', 'Injury') for tactical instructions.";
  };

  const handleSend = () => {
    if (!input) return;
    const userMsg = { role: 'user', text: input };
    const aiMsg = { role: 'ai', text: getAIResponse(input) };
    setChat([...chat, userMsg, aiMsg]);
    setInput('');
  };

  return (
    <div style={styles.aiWrapper}>
      {isOpen && (
        <div style={styles.aiChatBox}>
          <div style={styles.aiHeader}>SOS-AI ASSISTANT</div>
          <div style={styles.aiBody}>
            {chat.map((m, i) => (
              <div key={i} style={m.role === 'ai' ? styles.aiMsg : styles.userMsg}>
                <div dangerouslySetInnerHTML={{ __html: m.text }}></div>
              </div>
            ))}
          </div>
          <div style={styles.aiInputArea}>
            <input value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSend()} placeholder="Ask AI..." style={styles.aiInput} />
            <button onClick={handleSend} style={styles.aiSend}>Send</button>
          </div>
        </div>
      )}
      <button onClick={() => setIsOpen(!isOpen)} style={styles.aiToggle}>🤖</button>
    </div>
  );
}

function UserSOSView() {
  const { user, setIncidents, incidents, logout } = useContext(AuthContext);
  const [emergencyType, setEmergencyType] = useState('Medical');
  const [image, setImage] = useState(null);

  const handleImage = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => setImage(reader.result);
    if (file) reader.readAsDataURL(file);
  };

  const trigger = () => {
    const newInc = {
      id: Date.now(),
      type: emergencyType,
      user_name: user.name,
      lat: 31.52 + (Math.random() * 0.05),
      lng: 74.35 + (Math.random() * 0.05),
      created_at: new Date(),
      attachment: image
    };
    setIncidents([newInc, ...incidents]);
    alert(`🚨 SOS DISPATCHED: ${emergencyType.toUpperCase()} UNITS EN ROUTE`);
    setImage(null);
  };

  return (
    <div style={styles.userViewWrapper}>
      <div style={styles.mainControlPanel}>
        <div style={styles.deviceHeader}>
          <span>📶 5G / SECURE-LINK</span>
          <span>🔋 98%</span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div style={{ textAlign: 'left' }}>
            <h3 style={{ margin: 0, color: '#ef4444' }}>ID: {user.name.toUpperCase()}</h3>
            <span style={{ fontSize: '10px', color: '#94a3b8' }}>LAT: 31.5204 | LNG: 74.3587</span>
          </div>
          <button onClick={logout} style={styles.logoutBtnSmall}>LOGOUT</button>
        </div>

        <div style={styles.typeSelectorGrid}>
          {['Medical', 'Police', 'Fire'].map(type => (
            <button key={type} onClick={() => setEmergencyType(type)}
              style={{ ...styles.typeBox, background: emergencyType === type ? '#ef4444' : '#1e293b' }}>
              {type === 'Medical' ? '🚑' : type === 'Police' ? '👮' : '🔥'} {type.toUpperCase()}
            </button>
          ))}
        </div>

        <div style={styles.uploadBox}>
          <label style={{ cursor: 'pointer', display: 'block' }}>
            <span style={{ fontSize: '11px', color: '#94a3b8' }}>📷 ATTACH VISUAL EVIDENCE</span>
            <input type="file" accept="image/*" onChange={handleImage} style={{ display: 'none' }} />
          </label>
          {image && <img src={image} style={styles.previewImg} alt="Preview" />}
        </div>

        <div style={styles.pulseWrapper}>
          <div className="pulse-ring"></div>
          <button onClick={trigger} style={styles.bigRedButton}>SOS</button>
        </div>
      </div>
      <AIAssistant />
    </div>
  );
}

function AdminDashboard() {
  const { incidents, logout } = useContext(AuthContext);
  const mapRef = useRef(null);
  const mapInstance = useRef(null);

  useEffect(() => {
    if (window.L && !mapInstance.current && mapRef.current) {
      mapInstance.current = window.L.map(mapRef.current, { zoomControl: false }).setView([31.52, 74.35], 13);
      window.L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapInstance.current);
    }
    
    if (mapInstance.current) {
      incidents.forEach(i => {
        window.L.marker([i.lat, i.lng]).addTo(mapInstance.current)
          .bindPopup(`<b>${i.type}</b><br/>User: ${i.user_name}`);
      });
    }
  }, [incidents]);

  return (
    <div style={{ display: 'flex', height: '94vh', width: '100vw' }}>
      <div ref={mapRef} style={{ flex: 1, background: '#000', height: '100%' }}></div>
      <div style={styles.adminSidebar}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 style={{ color: '#ef4444', margin: 0 }}>HQ FEED</h2>
          <button onClick={logout} style={styles.logoutBtnSmall}>Exit</button>
        </div>
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {incidents.map(i => (
            <div key={i.id} style={styles.alertCard}>
              <div style={{ fontWeight: 'bold', color: '#ef4444' }}>🚨 {i.type.toUpperCase()}</div>
              <div style={{ fontSize: '11px', color: '#94a3b8' }}>{i.user_name} | {new Date(i.created_at).toLocaleTimeString()}</div>
              {i.attachment && <img src={i.attachment} style={styles.evidenceThumb} alt="evidence" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  appContainer: { height: '100vh', background: '#0f172a', color: '#fff', display: 'flex', flexDirection: 'column', fontFamily: "'Inter', sans-serif", overflow: 'hidden' },
  mainArea: { flex: 1, display: 'flex', overflow: 'hidden' },
  userViewWrapper: { flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '20px', position: 'relative' },
  loginPage: { height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', background: '#0f172a' },
  heroTitle: { fontSize: '50px', fontWeight: '900', color: '#ef4444' },
  glassCard: { background: '#1e293b', padding: '40px', borderRadius: '20px', width: '320px', textAlign: 'center' },
  darkInput: { width: '100%', padding: '12px', marginBottom: '10px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '8px', boxSizing: 'border-box' },
  primaryBtn: { width: '100%', padding: '12px', background: '#ef4444', border: 'none', color: '#fff', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' },
  roleCard: { width: '180px', padding: '30px', border: '1px solid #334155', borderRadius: '15px', background: '#1e293b', color: '#fff', cursor: 'pointer' },
  mainControlPanel: { background: 'rgba(30, 41, 59, 0.6)', backdropFilter: 'blur(15px)', padding: '30px', borderRadius: '28px', border: '1px solid rgba(255,255,255,0.1)', width: '450px', boxShadow: '0 25px 50px rgba(0,0,0,0.5)' },
  deviceHeader: { display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#64748b', marginBottom: '15px', fontFamily: 'monospace' },
  typeSelectorGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', marginBottom: '20px' },
  typeBox: { padding: '10px', border: '1px solid #334155', color: '#fff', borderRadius: '8px', cursor: 'pointer', fontSize: '11px', fontWeight: 'bold', textAlign: 'center' },
  uploadBox: { background: 'rgba(15, 23, 42, 0.5)', padding: '12px', borderRadius: '12px', border: '1px dashed #334155', marginBottom: '20px', textAlign: 'center' },
  previewImg: { width: '100%', height: '100px', objectFit: 'cover', borderRadius: '8px', marginTop: '10px', border: '1px solid #ef4444' },
  pulseWrapper: { position: 'relative', width: '160px', height: '160px', margin: '0 auto' },
  bigRedButton: { width: '140px', height: '140px', borderRadius: '50%', background: '#ef4444', border: 'none', color: '#fff', fontSize: '28px', fontWeight: '900', cursor: 'pointer', zIndex: 10, position: 'relative', boxShadow: '0 0 30px rgba(239, 68, 68, 0.5)' },
  adminSidebar: { width: '400px', background: '#111827', padding: '20px', borderLeft: '1px solid #334155', display: 'flex', flexDirection: 'column' },
  alertCard: { background: '#1e293b', padding: '15px', borderRadius: '12px', marginBottom: '15px', borderLeft: '4px solid #ef4444' },
  evidenceThumb: { width: '100%', borderRadius: '8px', marginTop: '10px' },
  aiWrapper: { position: 'fixed', bottom: '100px', right: '40px', zIndex: 1000 },
  aiToggle: { width: '65px', height: '65px', borderRadius: '50%', background: '#ef4444', border: 'none', fontSize: '32px', cursor: 'pointer', boxShadow: '0 10px 20px rgba(0,0,0,0.4)' },
  aiChatBox: { width: '350px', height: '500px', background: '#1e293b', borderRadius: '20px', marginBottom: '20px', display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid #334155', boxShadow: '0 20px 40px rgba(0,0,0,0.6)' },
  aiHeader: { background: '#ef4444', padding: '15px', fontWeight: 'bold', fontSize: '13px', letterSpacing: '1px' },
  aiBody: { flex: 1, padding: '15px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', background: '#0f172a' },
  aiMsg: { alignSelf: 'flex-start', background: '#1e293b', padding: '15px', borderRadius: '15px', fontSize: '13px', maxWidth: '90%', lineHeight: '1.6', color: '#fff', border: '1px solid #334155', fontFamily: "'Courier New', monospace", borderBottomLeftRadius: '2px' },
  userMsg: { alignSelf: 'flex-end', background: '#ef4444', padding: '10px 15px', borderRadius: '15px', fontSize: '13px', maxWidth: '80%', borderBottomRightRadius: '2px' },
  aiInputArea: { padding: '12px', background: '#1e293b', display: 'flex', gap: '8px', borderTop: '1px solid #334155' },
  aiInput: { flex: 1, background: '#0f172a', border: 'none', color: '#fff', fontSize: '13px', outline: 'none', padding: '8px', borderRadius: '5px' },
  aiSend: { background: '#ef4444', border: 'none', color: '#fff', borderRadius: '5px', padding: '0 15px', cursor: 'pointer', fontWeight: 'bold' },
  tickerBar: { height: '6vh', background: '#ef4444', overflow: 'hidden', display: 'flex', alignItems: 'center' },
  logoutBtnSmall: { background: 'rgba(255,255,255,0.1)', border: 'none', color: '#fff', borderRadius: '5px', padding: '5px 12px', cursor: 'pointer', fontSize: '11px' },
  toggleLink: { fontSize: '11px', color: '#94a3b8', marginTop: '10px', cursor: 'pointer' },
  backBtn: { background: 'none', border: 'none', color: '#475569', marginTop: '10px', cursor: 'pointer' }
};